# Django layout scaffolder

This utility creates a small, responsive Django site shell for the Electric
Sting Racing website. It is intentionally safe to run against an existing
project: new files are created only when absent, and settings/URL changes are
conservative and idempotent.

## Usage

From the root of an existing Django project:

```bash
python scaffold_django_layout.py . --app home
```

For a reusable CLI installation:

```bash
python -m pip install -e .
scaffold-django-layout . --app home
```

Preview the changes first:

```bash
python scaffold_django_layout.py . --app home --dry-run
```

To create assets without changing `settings.py` or the project URL file:

```bash
python scaffold_django_layout.py . --app home --no-integrate
```

Then verify the Django project:

```bash
python manage.py check
python manage.py runserver
```

## Design

The executable `scaffold_django_layout.py` is only an entrypoint. The
implementation is split by responsibility:

- `project.py` discovers the project and creates a missing app.
- `patchers.py` contains pure, idempotent text transformations.
- `filesystem.py` owns non-destructive file operations.
- `assets.py` loads packaged templates and CSS.
- `scaffolder.py` coordinates the workflow.
- `cli.py` defines the user-facing command line.

Add new pages or assets under `django_layout_scaffolder/assets/` and add their
destination to `scaffolder.py`; keep project mutation logic in `patchers.py`.

## Tests

The test suite uses only Python's standard library:

```bash
python -m unittest discover -s tests -v
```
